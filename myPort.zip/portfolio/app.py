from flask import Flask, send_from_directory

app = Flask(__name__, static_folder=None)


@app.route("/")
def inicio():
    return send_from_directory(".", "index.html")


@app.route("/css/<path:arquivo>")
def css(arquivo):
    return send_from_directory("css", arquivo)


@app.route("/js/<path:arquivo>")
def js(arquivo):
    return send_from_directory("js", arquivo)


@app.route("/img/<path:arquivo>")
def img(arquivo):
    return send_from_directory("img", arquivo)


if __name__ == "__main__":
    app.run(debug=True)
