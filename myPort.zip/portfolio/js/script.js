// Ano automático no rodapé
document.getElementById('ano').textContent = new Date().getFullYear();

// Menu hambúrguer
const menuBtn = document.getElementById('menu-btn');
const menu = document.getElementById('menu');
function setMenu(aberto) {
  menu.classList.toggle('open', aberto);
  menuBtn.setAttribute('aria-expanded', aberto);
  menuBtn.setAttribute('aria-label', aberto ? 'Fechar menu' : 'Abrir menu');
}
menuBtn.addEventListener('click', () => setMenu(!menu.classList.contains('open')));
menu.addEventListener('click', e => { if (e.target.tagName === 'A') setMenu(false); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });
